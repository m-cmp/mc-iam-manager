This directory contains configuration and programs used to
integrate with the QUIC Interop Test Runner.

The QUIC Interop Test Runner executes a variety of test cases
against a matrix of clients and servers.

https://github.com/marten-seemann/quic-interop-runner
